package com.cg.walletapp.beans;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable

public class Wallet {

@Column(name="balance",length=50)
	private BigDecimal balance=new BigDecimal("0");

	
	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	@Override
		public String toString() {
		return " balance="+balance;
	}
}