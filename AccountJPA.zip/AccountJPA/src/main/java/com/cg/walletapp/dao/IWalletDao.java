package com.cg.walletapp.dao;


import java.util.List;

import com.cg.walletapp.beans.Customer;
import com.cg.walletapp.exception.WalletException;

public interface IWalletDao {

	public void addAccountDao(Customer customer);

	public Customer findOne(String mobnum);

	public void addTransactions(String mobnum, String string) throws WalletException;

	public List<String> printTransactionsDao(String mobnum) throws WalletException;

	public boolean checkMobno(String mobnum);

	public void updateBalance(Customer customer);

	public abstract void commitTransaction();

	public abstract void beginTransaction();

}