package com.cg.walletapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import com.capgemini.tcc.util.DBUtil;
import com.cg.walletapp.beans.Customer;
import com.cg.walletapp.exception.IWalletException;
import com.cg.walletapp.exception.WalletException;

public class WalletDaoImpl implements IWalletDao {
	private EntityManager entityManager = null;

	Connection con = null;

	public WalletDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
		con = DBUtil.getConnect();
	}

	public void addAccountDao(Customer customer) {
		entityManager.persist(customer);
	}

	public Customer findOne(String mobnum) {

		return entityManager.find(Customer.class, mobnum);

	}

	public void addTransactions(String mobnum, String str) throws WalletException {

		try {
			String sql = "INSERT INTO TRANSACTIONS VALUES(?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobnum);
			pstmt.setString(2, str);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new WalletException(IWalletException.ERROR3);
		}

	}

	public List<String> printTransactionsDao(String mobnum) throws WalletException {
	

		List<String> transaction = new ArrayList<String>();
		String sql = "SELECT * FROM TRANSACTIONS WHERE MOBILE=?";

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobnum);
			ResultSet res = pstmt.executeQuery();

			if (res.next()) {
				while (res.next()) {
					transaction.add(res.getString(2));

				}

			}
		} catch (SQLException e) {

			System.out.println(e.getMessage());
			throw new WalletException(IWalletException.ERROR3);
		}
		return transaction;

	}

	public boolean checkMobno(String mobnum) {
		boolean flag = false;

		Customer customer = entityManager.find(Customer.class, mobnum);

		if (customer != null) {
			flag = true;
		}

		return flag;
	}

	public void updateBalance(Customer customer) {

		entityManager.merge(customer);
	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();

	}

	public void beginTransaction() {
		entityManager.getTransaction().begin();

	}

}