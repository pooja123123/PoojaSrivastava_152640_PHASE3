package com.cg.walletapp.exception;

public interface IWalletException {

	String ERROR1="INVALID INPUT!!!!";
	String ERROR2="INSUFIICIENT BALANCE !!!!";
	String ERROR3= "INVALID INPUT!!!! ";
}
