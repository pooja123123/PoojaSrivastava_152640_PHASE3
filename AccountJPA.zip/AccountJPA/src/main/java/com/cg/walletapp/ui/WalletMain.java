package com.cg.walletapp.ui;

import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;

import com.cg.walletapp.beans.Customer;
import com.cg.walletapp.exception.WalletException;
import com.cg.walletapp.service.IWalletService;
import com.cg.walletapp.service.WalletService;

public class WalletMain {
	static IWalletService service = new WalletService();

	public static void printMenu() {
		System.out.println();
	
		System.out.println("  " + "************************PAYTM WALLET APP*************************");
		System.out.println("  " + "*                        1: SIGNUP FOR NEW ACCOUNT              *");
		System.out.println("  " + "*                        2: LOGIN  FOR EXISTING ACCOUNT         *");
		System.out.println("  " + "*                        3: EXIT                                *");
		
		System.out.println("Enter your Choice from 1 to 3");
	}

	public static void printDetails() {
		System.out.println();

		System.out.println("  " + "***************************PAYTM WALLET APP**********************");
		System.out.println("  " + "*                        1: Show Balance                        *");
		System.out.println("  " + "*                        2: Deposit Amount                      *");
		System.out.println("  " + "*                        3: Withdraw Amount                     *");
		System.out.println("  " + "*                        4: Fund Transfer                       *");
		System.out.println("  " + "*                        5: Print Transaction                   *");
		System.out.println("  " + "*                        6: LOGOUT                              *");
		
		System.out.println("Enter your Choice from 1 to 6");
	}

	public static void printCases(String mobnum) {
		int choice1 = 0;
		Scanner scanner1 = new Scanner(System.in);
		do {
			printDetails();
			System.out.println("Enter your choice: ");
			choice1 = scanner1.nextInt();
			switch (choice1) {
			case 1:
				
				try {
					Customer custom1 = service.showBalance(mobnum);
					System.out.println("Hello!  " + custom1.getName() + "\nAvailable` Balance is :"
							+ custom1.getWalletBalance());
				} catch (WalletException e1) {

					System.out.println(e1.getMessage());
				}break;
			case 2:
				System.out.println("Enter the amount you want to deposit:");
				BigDecimal amount1 = scanner1.nextBigDecimal();
				BigDecimal newbalance;
				try {
					newbalance = service.depositBalance(mobnum, amount1);
					System.out.println("Hello :" + service.showBalance(mobnum).getName()
							+ " Your New balance is :" + newbalance);
				} catch (WalletException e1) {

					System.out.println(e1.getMessage());
				}

				break;
			case 3:

				System.out.println("Enter the amount you want to withdraw:");
				BigDecimal amount2 = scanner1.nextBigDecimal();
				try {
					if (service.validateRechargeAmount(mobnum, amount2)) {
						BigDecimal newbalance2 = service.withdrawal(mobnum, amount2);
						System.out.println("Hello :" +service.showBalance(mobnum).getName()
								+ " Your New balance is :" + newbalance2);
					}
				} catch (WalletException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				try {
					System.out.println("Enter the reciever mobile number::");
					String mobnumber = scanner1.next();
					if (service.checkMobno(mobnumber)) {
						System.out.println("Enter the amount you want to transfer");
						BigDecimal transferamount = scanner1.nextBigDecimal();
						if (service.validateRechargeAmount(mobnum, transferamount)) {
							BigDecimal balance = service.transferMoney(mobnum, mobnumber, transferamount);
							System.out.println("Hello :" + service.showBalance(mobnum).getName()
									+ " Your New balance is :" + balance);
						}
					}
					}
				 catch (WalletException e) {
					System.out.println(e.getMessage());
				}

				break;
			case 5:
				List<String> newList;
				try {
					newList = service.printTransactionDetails(mobnum);
					for (String i : newList) {
						System.out.println(i);
					}
				} catch (WalletException e) {

					System.out.println(e.getMessage());
				}

				break;
			case 6:
				main(null);
				break;

			}
		} while (choice1 != 6);
		scanner1.close();
	}

	public static void main(String[] args) {
		int choice = 0;

		Scanner scanner = new Scanner(System.in);
		do {
			printMenu();
			System.out.println("Enter your choice:");
			choice = scanner.nextInt();
			Customer customer = new Customer();

			switch (choice) {
			case 1:
				try {
					System.out.println("Enter Name:");
					String name = scanner.next();
					System.out.println("Enter Mobile Number:");
					String mnumber = scanner.next();
					System.out.println("Enter the amount you want to add to your account:");
					BigDecimal amount = scanner.nextBigDecimal();
					service.validateDetails(name, mnumber);
					customer.setName(name);
					customer.setMobileNo(mnumber);
					customer.setWalletBalance(amount);
					service.addAccount(customer);

				} catch (WalletException e) {
					System.out.println(e.getMessage());
				}

				break;
			case 2:
				System.out.println("Enter mobile number");
				String mobnum = scanner.next();
				try {
					if (service.checkMobno(mobnum)) {
						printCases(mobnum);
					} else {
						System.out.println("Mobile number does not exist");

					}
				} catch (WalletException e) {
					System.out.println(e.getMessage());

				}
				
				break;
			case 3:
				System.exit(0);

				break;

			}

		} while (choice != 3);

		scanner.close();
	}

}
